export type Truck = {
  id: number
  name: string
  type: string
  image: string
  capacity: string
  route: string
  from: string
  to: string
  price: number
  rating: number
  trips: number
  available: string
  driver: string
  verified: boolean
}

export const trucks: Truck[] = [
  {
    id: 1,
    name: "Volvo FH16",
    type: "Flatbed",
    image:
      "https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?auto=format&fit=crop&w=900&q=85",
    capacity: "22 tons",
    route: "Lagos → Abuja",
    from: "Lagos",
    to: "Abuja",
    price: 420000,
    rating: 4.9,
    trips: 184,
    available: "Today",
    driver: "Chinedu Okafor",
    verified: true,
  },
  {
    id: 2,
    name: "Mercedes Actros",
    type: "Box Truck",
    image:
      "https://images.unsplash.com/photo-1695222833131-54ee679ae8e5?auto=format&fit=crop&w=900&q=85",
    capacity: "18 tons",
    route: "Lagos → Ibadan",
    from: "Lagos",
    to: "Ibadan",
    price: 185000,
    rating: 4.8,
    trips: 127,
    available: "Tomorrow",
    driver: "Tunde Adebayo",
    verified: true,
  },
  {
    id: 3,
    name: "MAN TGS",
    type: "Refrigerated",
    image:
      "https://images.unsplash.com/photo-1616432043562-3671ea2e5242?auto=format&fit=crop&w=900&q=85",
    capacity: "15 tons",
    route: "Abuja → Kano",
    from: "Abuja",
    to: "Kano",
    price: 310000,
    rating: 4.7,
    trips: 98,
    available: "Jun 24",
    driver: "Musa Ibrahim",
    verified: true,
  },
  {
    id: 4,
    name: "DAF XF",
    type: "Tanker",
    image:
      "https://images.unsplash.com/photo-1592805144716-feeccccef5ac?auto=format&fit=crop&w=900&q=85",
    capacity: "30,000 L",
    route: "Port Harcourt → Enugu",
    from: "Port Harcourt",
    to: "Enugu",
    price: 395000,
    rating: 4.6,
    trips: 76,
    available: "Jun 26",
    driver: "Emeka Nwosu",
    verified: true,
  },
  {
    id: 5,
    name: "Scania R450",
    type: "Container",
    image:
      "https://images.unsplash.com/photo-1473445730015-841f29a9490b?auto=format&fit=crop&w=900&q=85",
    capacity: "28 tons",
    route: "Apapa → Kaduna",
    from: "Apapa",
    to: "Kaduna",
    price: 540000,
    rating: 4.9,
    trips: 212,
    available: "Jun 28",
    driver: "David Eze",
    verified: true,
  },
  {
    id: 6,
    name: "Iveco S-Way",
    type: "Tipper",
    image:
      "https://images.unsplash.com/photo-1651928977880-ffb2d963b6b4?auto=format&fit=crop&w=900&q=85",
    capacity: "20 tons",
    route: "Ogun → Lagos",
    from: "Ogun",
    to: "Lagos",
    price: 155000,
    rating: 4.5,
    trips: 64,
    available: "Today",
    driver: "Kunle Ajayi",
    verified: true,
  },
]

export const loads = [
  {
    id: "LD-2084",
    cargo: "Bagged cement",
    route: "Lagos → Abuja",
    weight: "18 tons",
    date: "24 Jun",
    budget: "₦380k–₦450k",
    match: 96,
  },
  {
    id: "LD-2079",
    cargo: "Consumer electronics",
    route: "Ibadan → Kano",
    weight: "12 tons",
    date: "25 Jun",
    budget: "₦410k–₦480k",
    match: 89,
  },
  {
    id: "LD-2071",
    cargo: "Fresh produce",
    route: "Abuja → Kaduna",
    weight: "8 tons",
    date: "Today",
    budget: "₦160k–₦210k",
    match: 84,
  },
]

export const categories = [
  { name: "Flatbed", detail: "Heavy & oversized goods", icon: "PanelsTopLeft" },
  { name: "Box truck", detail: "Protected general cargo", icon: "Package" },
  { name: "Refrigerated", detail: "Temperature controlled", icon: "Snowflake" },
  { name: "Tanker", detail: "Liquid transportation", icon: "Droplets" },
  { name: "Tipper", detail: "Construction materials", icon: "Container" },
  { name: "Container", detail: "Port & long haul", icon: "Boxes" },
]
