import { useEffect, useMemo, useState } from "react"
import {
  ArrowRight,
  BarChart3,
  Bell,
  Boxes,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleDollarSign,
  ClipboardList,
  Clock3,
  Container,
  CreditCard,
  Droplets,
  Gauge,
  LayoutDashboard,
  MapPin,
  Menu,
  Moon,
  Package,
  PanelsTopLeft,
  Plus,
  Search,
  ShieldCheck,
  Snowflake,
  Star,
  Sun,
  TrendingUp,
  Truck,
  UserRound,
  Users,
  WalletCards,
  X,
  Zap,
} from "lucide-react"
import Logo from "./components/Logo"
import Modal from "./components/Modal"
import TruckCard from "./components/TruckCard"
import { categories, loads, trucks, type Truck as TruckType } from "./data/demo"

type Page = "home" | "trucks" | "customer" | "driver" | "admin"
type AuthRole = "customer" | "driver"
const iconMap = {
  PanelsTopLeft,
  Package,
  Snowflake,
  Droplets,
  Container,
  Boxes,
}

export default function App() {
  const [page, setPage] = useState<Page>("home")
  const [dark, setDark] = useState(
    () => localStorage.getItem("sf-theme") === "dark",
  )
  const [mobileOpen, setMobileOpen] = useState(false)
  const [auth, setAuth] = useState<AuthRole | null>(null)
  const [bookTruck, setBookTruck] = useState<TruckType | null>(null)
  const [toast, setToast] = useState("")
  const [search, setSearch] = useState({ from: "", to: "", date: "" })

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark)
    localStorage.setItem("sf-theme", dark ? "dark" : "light")
  }, [dark])

  const navigate = (next: Page) => {
    setPage(next)
    setMobileOpen(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }
  const notify = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(""), 3200)
  }
  const runSearch = () => {
    navigate("trucks")
    notify(
      search.from || search.to
        ? `Showing matching trucks${search.from ? ` from ${search.from}` : ""}`
        : "Showing all available trucks",
    )
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="nav-wrap">
          <button className="logo-button" onClick={() => navigate("home")}>
            <Logo />
          </button>
          <nav className="desktop-nav" aria-label="Main navigation">
            <button
              className={page === "home" ? "active" : ""}
              onClick={() => navigate("home")}
            >
              Home
            </button>
            <button
              className={page === "trucks" ? "active" : ""}
              onClick={() => navigate("trucks")}
            >
              Find trucks
            </button>
            <button onClick={() => navigate("driver")}>Find loads</button>
            <button
              onClick={() =>
                document
                  .querySelector("#how")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
            >
              How it works
            </button>
          </nav>
          <div className="nav-actions">
            <button
              className="icon-btn"
              onClick={() => setDark(!dark)}
              aria-label="Toggle color mode"
            >
              {dark ? <Sun /> : <Moon />}
            </button>
            <button className="login-btn" onClick={() => setAuth("customer")}>
              Log in
            </button>
            <button
              className="btn btn-orange desktop-cta"
              onClick={() => setAuth("driver")}
            >
              List your truck <ArrowRight size={17} />
            </button>
            <button
              className="menu-btn"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Open menu"
            >
              {mobileOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        {mobileOpen && (
          <div className="mobile-nav">
            <button onClick={() => navigate("home")}>Home</button>
            <button onClick={() => navigate("trucks")}>Find trucks</button>
            <button onClick={() => navigate("driver")}>Find loads</button>
            <button onClick={() => navigate("customer")}>
              Customer dashboard
            </button>
            <button onClick={() => navigate("admin")}>Admin dashboard</button>
          </div>
        )}
      </header>

      <main>
        {page === "home" && (
          <Landing
            search={search}
            setSearch={setSearch}
            runSearch={runSearch}
            navigate={navigate}
            onBook={setBookTruck}
          />
        )}
        {page === "trucks" && (
          <Listings initialSearch={search} onBook={setBookTruck} />
        )}
        {page === "customer" && (
          <CustomerDashboard navigate={navigate} notify={notify} />
        )}
        {page === "driver" && <DriverDashboard notify={notify} />}
        {page === "admin" && <AdminDashboard />}
      </main>

      <Footer navigate={navigate} />

      {auth && (
        <AuthModal
          role={auth}
          onClose={() => setAuth(null)}
          onSuccess={() => {
            setAuth(null)
            navigate(auth === "driver" ? "driver" : "customer")
            notify("Welcome to your SuperFast demo dashboard")
          }}
        />
      )}
      {bookTruck && (
        <BookingModal
          truck={bookTruck}
          onClose={() => setBookTruck(null)}
          onConfirm={() => {
            setBookTruck(null)
            navigate("customer")
            notify("Demo booking request submitted successfully")
          }}
        />
      )}
      {toast && (
        <div className="toast">
          <CheckCircle2 /> {toast}
        </div>
      )}
    </div>
  )
}

function Landing({
  search,
  setSearch,
  runSearch,
  navigate,
  onBook,
}: {
  search: { from: string; to: string; date: string }
  setSearch: (value: { from: string; to: string; date: string }) => void
  runSearch: () => void
  navigate: (page: Page) => void
  onBook: (truck: TruckType) => void
}) {
  return (
    <>
      <section className="hero">
        <div className="hero-glow" />
        <div className="hero-inner">
          <div className="hero-copy">
            <div className="hero-pill">
              <Zap size={14} fill="currentColor" /> Logistics, intelligently
              matched
            </div>
            <h1>
              Move goods.
              <br />
              <span>Not empty trucks.</span>
            </h1>
            <p>
              Compare verified trucks, get competitive offers, and move your
              goods across Nigeria with confidence.
            </p>
            <div className="proof-row">
              <div className="proof-faces">
                <span>AO</span>
                <span>TN</span>
                <span>MK</span>
                <span>+2k</span>
              </div>
              <div>
                <strong>Trusted by 2,000+ businesses</strong>
                <div className="stars">
                  <Star />
                  <Star />
                  <Star />
                  <Star />
                  <Star /> 4.9
                </div>
              </div>
            </div>
          </div>
          <div className="hero-image">
            <img
              src="https://images.unsplash.com/photo-1592805144716-feeccccef5ac?auto=format&fit=crop&w=1500&q=90"
              alt="Freight truck driving on a highway at sunset"
            />
            <div className="live-card">
              <span>
                <Truck />
              </span>
              <div>
                <small>Active trucks nearby</small>
                <strong>284 available</strong>
              </div>
              <i />
            </div>
          </div>
        </div>
        <div className="search-panel">
          <div className="search-tabs">
            <button className="active">I need a truck</button>
            <button onClick={() => navigate("driver")}>I have a truck</button>
          </div>
          <div className="search-grid">
            <label>
              <span>
                <MapPin /> Pickup location
              </span>
              <input
                placeholder="e.g. Lagos"
                value={search.from}
                onChange={(e) => setSearch({ ...search, from: e.target.value })}
              />
            </label>
            <label>
              <span>
                <MapPin /> Destination
              </span>
              <input
                placeholder="e.g. Abuja"
                value={search.to}
                onChange={(e) => setSearch({ ...search, to: e.target.value })}
              />
            </label>
            <label>
              <span>
                <CalendarDays /> Loading date
              </span>
              <input
                type="date"
                value={search.date}
                onChange={(e) => setSearch({ ...search, date: e.target.value })}
              />
            </label>
            <button
              className="btn btn-orange search-button"
              onClick={runSearch}
            >
              <Search /> Search trucks
            </button>
          </div>
        </div>
      </section>

      <section className="section category-section">
        <div className="section-head">
          <div>
            <span className="kicker">Find the right fit</span>
            <h2>Truck for every kind of load</h2>
            <p>
              Choose from verified vehicles across all major truck categories.
            </p>
          </div>
          <button className="text-link" onClick={() => navigate("trucks")}>
            View all trucks <ArrowRight />
          </button>
        </div>
        <div className="category-grid">
          {categories.map((category) => {
            const Icon = iconMap[(category.icon as keyof typeof iconMap)]
            return (
              <button
                className="category-card"
                key={category.name}
                onClick={() => navigate("trucks")}
              >
                <span>
                  <Icon />
                </span>
                <div>
                  <strong>{category.name}</strong>
                  <small>{category.detail}</small>
                </div>
                <ArrowRight className="cat-arrow" />
              </button>
            )
          })}
        </div>
      </section>

      <section className="section featured">
        <div className="section-head">
          <div>
            <span className="kicker">Available today</span>
            <h2>Top-rated trucks near you</h2>
          </div>
          <button className="text-link" onClick={() => navigate("trucks")}>
            Browse marketplace <ArrowRight />
          </button>
        </div>
        <div className="truck-grid">
          {trucks.slice(0, 3).map((truck) => (
            <TruckCard key={truck.id} truck={truck} onBook={onBook} />
          ))}
        </div>
      </section>

      <section className="how-section" id="how">
        <div className="section">
          <div className="center-head">
            <span className="kicker light">Simple by design</span>
            <h2>From pickup to delivery in three steps</h2>
            <p>
              No endless calls. No uncertain prices. Just smarter logistics.
            </p>
          </div>
          <div className="steps">
            {[
              [
                Search,
                "01",
                "Tell us your route",
                "Enter pickup, destination, cargo details and preferred loading date.",
              ],
              [
                WalletCards,
                "02",
                "Compare offers",
                "Get transparent offers from verified drivers already heading your way.",
              ],
              [
                Truck,
                "03",
                "Book & move",
                "Choose your best match, confirm the booking and stay updated.",
              ],
            ].map(([Icon, no, title, text], i) => (
              <div className="step" key={String(title)}>
                <div className="step-icon">
                  <Icon size={27} />
                  <b>{no as string}</b>
                </div>
                <h3>{title as string}</h3>
                <p>{text as string}</p>
                {i < 2 && <div className="step-line" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section impact">
        <div className="impact-image">
          <img
            src="https://images.unsplash.com/photo-1694113372786-2553caec0c76?auto=format&fit=crop&w=1000&q=85"
            alt="White logistics truck on an open road"
          />
          <div className="impact-badge">
            <TrendingUp />
            <strong>32% less</strong>
            <span>empty return trips</span>
          </div>
        </div>
        <div className="impact-copy">
          <span className="kicker">Better for everyone</span>
          <h2>Every full truck moves business forward</h2>
          <p>
            SuperFast connects unused truck capacity with businesses that need
            it. Drivers earn more per route, customers pay fairer prices, and
            every journey creates less waste.
          </p>
          <div className="benefit-list">
            {[
              "Verified drivers and vehicles",
              "Upfront, competitive pricing",
              "Support from pickup to delivery",
            ].map((item) => (
              <div key={item}>
                <Check /> {item}
              </div>
            ))}
          </div>
          <button className="btn btn-dark" onClick={() => navigate("trucks")}>
            Find your truck <ArrowRight />
          </button>
        </div>
      </section>

      <section className="cta-band">
        <div>
          <span className="kicker light">Ready when you are</span>
          <h2>Make your next delivery SuperFast.</h2>
          <p>
            Join thousands of businesses and drivers moving smarter every day.
          </p>
        </div>
        <div>
          <button className="btn btn-white" onClick={() => navigate("trucks")}>
            Book a truck
          </button>
          <button
            className="btn btn-outline-light"
            onClick={() => navigate("driver")}
          >
            Find loads
          </button>
        </div>
      </section>
    </>
  )
}

function Listings({
  initialSearch,
  onBook,
}: {
  initialSearch: { from: string; to: string }
  onBook: (truck: TruckType) => void
}) {
  const [query, setQuery] = useState(initialSearch.from || initialSearch.to)
  const [type, setType] = useState("All")
  const [sort, setSort] = useState("recommended")
  const filtered = useMemo(
    () =>
      trucks
        .filter((t) => type === "All" || t.type === type)
        .filter((t) =>
          `${t.name} ${t.route} ${t.type}`
            .toLowerCase()
            .includes(query.toLowerCase()),
        )
        .sort((a, b) =>
          sort === "price" ? a.price - b.price : b.rating - a.rating,
        ),
    [query, type, sort],
  )
  return (
    <div className="page-wrap">
      <div className="page-heading">
        <div>
          <span className="kicker">Truck marketplace</span>
          <h1>Find your perfect truck</h1>
          <p>Compare verified vehicles and transparent prices.</p>
        </div>
        <div className="result-count">
          <strong>{filtered.length}</strong>
          <span>trucks found</span>
        </div>
      </div>
      <div className="market-layout">
        <aside className="filters">
          <div className="filter-head">
            <h3>Filters</h3>
            <button
              onClick={() => {
                setType("All")
                setQuery("")
              }}
            >
              Reset
            </button>
          </div>
          <label className="field-label">
            Search route or vehicle
            <div className="input-with-icon">
              <Search />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Lagos, Abuja..."
              />
            </div>
          </label>
          <div className="filter-group">
            <span>Truck type</span>
            {["All", ...categories.map((c) => c.name)].map((item) => (
              <button
                className={type === item ? "selected" : ""}
                onClick={() => setType(item)}
                key={item}
              >
                <i />
                {item}
                <small>
                  {item === "All"
                    ? trucks.length
                    : trucks.filter((t) => t.type === item).length}
                </small>
              </button>
            ))}
          </div>
          <div className="filter-promo">
            <ShieldCheck />
            <strong>Book with confidence</strong>
            <p>Every listed truck and driver is verified by our team.</p>
          </div>
        </aside>
        <div className="listings-main">
          <div className="list-toolbar">
            <span>{filtered.length} available trucks</span>
            <label>
              Sort by{" "}
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="recommended">Recommended</option>
                <option value="price">Lowest price</option>
              </select>
              <ChevronDown />
            </label>
          </div>
          {filtered.length ? (
            <div className="truck-grid listing-grid">
              {filtered.map((truck) => (
                <TruckCard key={truck.id} truck={truck} onBook={onBook} />
              ))}
            </div>
          ) : (
            <div className="empty">
              <Search />
              <h3>No matching trucks</h3>
              <p>Try changing your filters or route search.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function DashboardShell({
  role,
  active,
  children,
  navigate,
}: {
  role: "Customer" | "Driver"
  active: string
  children: React.ReactNode
  navigate?: (page: Page) => void
}) {
  const menu =
    role === "Customer"
      ? [
          [LayoutDashboard, "Overview"],
          [Search, "Find trucks"],
          [ClipboardList, "My requests"],
          [CalendarDays, "Bookings"],
          [CreditCard, "Payments"],
        ]
      : [
          [LayoutDashboard, "Overview"],
          [Search, "Matching loads"],
          [Truck, "My vehicles"],
          [ClipboardList, "My offers"],
          [CalendarDays, "Bookings"],
        ]
  return (
    <div className="dashboard-shell">
      <aside className="dash-side">
        <Logo />
        <div className="account-chip">
          <span>{role === "Customer" ? "OA" : "CO"}</span>
          <div>
            <strong>
              {role === "Customer" ? "Olamide Adeyemi" : "Chinedu Okafor"}
            </strong>
            <small>{role} account</small>
          </div>
        </div>
        <nav>
          {menu.map(([Icon, label]) => (
            <button
              className={label === active ? "active" : ""}
              key={String(label)}
              onClick={() => label === "Find trucks" && navigate?.("trucks")}
            >
              <Icon size={19} />
              {label as string}
            </button>
          ))}
        </nav>
        <button className="support-card">
          <span>Need help?</span>
          <small>Our support team is online</small>
          <b>Chat with us →</b>
        </button>
      </aside>
      <div className="dash-content">
        <div className="dash-top">
          <div>
            <span>SuperFast /</span> {active}
          </div>
          <div>
            <button className="icon-btn">
              <Bell />
            </button>
            <span className="dash-avatar">
              {role === "Customer" ? "OA" : "CO"}
            </span>
          </div>
        </div>
        {children}
      </div>
    </div>
  )
}

function CustomerDashboard({
  navigate,
  notify,
}: {
  navigate: (page: Page) => void
  notify: (message: string) => void
}) {
  const [postOpen, setPostOpen] = useState(false)
  return (
    <DashboardShell role="Customer" active="Overview" navigate={navigate}>
      <div className="dash-main">
        <div className="dash-welcome">
          <div>
            <span>Tuesday, 18 June</span>
            <h1>Good morning, Olamide</h1>
            <p>Here’s what’s happening with your shipments.</p>
          </div>
          <button className="btn btn-orange" onClick={() => setPostOpen(true)}>
            <Plus /> Post a request
          </button>
        </div>
        <div className="stats-grid">
          {[
            [ClipboardList, "Active requests", "3", "+1 this week"],
            [Truck, "In transit", "2", "On schedule"],
            [CheckCircle2, "Completed", "24", "+12% this month"],
            [WalletCards, "Total spent", "₦4.8m", "This year"],
          ].map(([Icon, label, value, note]) => (
            <div className="stat-card" key={String(label)}>
              <span>
                <Icon />
              </span>
              <small>{label as string}</small>
              <strong>{value as string}</strong>
              <em>{note as string}</em>
            </div>
          ))}
        </div>
        <div className="dash-grid">
          <section className="panel span-2">
            <div className="panel-head">
              <div>
                <h2>Active shipments</h2>
                <p>Track your current deliveries</p>
              </div>
              <button>View all</button>
            </div>
            <div className="shipment-list">
              {[
                [
                  "SF-30982",
                  "Lagos",
                  "Abuja",
                  "In transit",
                  "Arrives tomorrow",
                  68,
                ],
                [
                  "SF-30974",
                  "Apapa",
                  "Ibadan",
                  "Loading",
                  "Pickup today, 2:00 PM",
                  24,
                ],
              ].map(([id, from, to, status, eta, progress]) => (
                <div className="shipment" key={String(id)}>
                  <span className="shipment-icon">
                    <Truck />
                  </span>
                  <div className="shipment-info">
                    <div>
                      <strong>
                        {from as string} <ArrowRight /> {to as string}
                      </strong>
                      <span
                        className={`status ${
                          status === "Loading" ? "orange" : ""
                        }`}
                      >
                        {status as string}
                      </span>
                    </div>
                    <small>
                      {id as string} · {eta as string}
                    </small>
                    <div className="progress">
                      <i style={{ width: `${progress}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
          <section className="panel">
            <div className="panel-head">
              <div>
                <h2>Quick search</h2>
                <p>Find a truck now</p>
              </div>
            </div>
            <div className="quick-form">
              <label>
                Pickup
                <input placeholder="Lagos" />
              </label>
              <label>
                Destination
                <input placeholder="Abuja" />
              </label>
              <button
                className="btn btn-dark"
                onClick={() => navigate("trucks")}
              >
                <Search /> Search trucks
              </button>
            </div>
          </section>
          <section className="panel span-3">
            <div className="panel-head">
              <div>
                <h2>Recent requests</h2>
                <p>Your latest transport requests</p>
              </div>
              <button>View all</button>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Request</th>
                    <th>Route</th>
                    <th>Cargo</th>
                    <th>Offers</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    [
                      "#RQ-1084",
                      "Lagos → Kano",
                      "Building materials",
                      "8 offers",
                      "Open",
                    ],
                    [
                      "#RQ-1081",
                      "Abuja → Enugu",
                      "Office equipment",
                      "5 offers",
                      "Reviewing",
                    ],
                    [
                      "#RQ-1072",
                      "Ogun → Lagos",
                      "Packaged foods",
                      "—",
                      "Booked",
                    ],
                  ].map((r) => (
                    <tr key={r[0]}>
                      {r.map((v, i) => (
                        <td key={v}>
                          {i === 4 ? <span className="status">{v}</span> : v}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
      {postOpen && (
        <RequestModal
          onClose={() => setPostOpen(false)}
          onSubmit={() => {
            setPostOpen(false)
            notify("Transportation request posted to matching drivers")
          }}
        />
      )}
    </DashboardShell>
  )
}

function DriverDashboard({ notify }: { notify: (message: string) => void }) {
  const [offerLoad, setOfferLoad] = useState<typeof loads[0] | null>(null)
  const [vehicleOpen, setVehicleOpen] = useState(false)
  return (
    <DashboardShell role="Driver" active="Overview">
      <div className="dash-main">
        <div className="dash-welcome">
          <div>
            <span>Driver command center</span>
            <h1>Keep your truck earning</h1>
            <p>3 new loads match your preferred routes today.</p>
          </div>
          <button
            className="btn btn-orange"
            onClick={() => setVehicleOpen(true)}
          >
            <Plus /> Add vehicle
          </button>
        </div>
        <div className="stats-grid">
          {[
            [Gauge, "Route match score", "94%", "Excellent"],
            [CircleDollarSign, "This month", "₦1.24m", "+18.4%"],
            [Truck, "Completed trips", "184", "98% on time"],
            [Star, "Driver rating", "4.9", "From 126 reviews"],
          ].map(([Icon, label, value, note]) => (
            <div className="stat-card" key={String(label)}>
              <span>
                <Icon />
              </span>
              <small>{label as string}</small>
              <strong>{value as string}</strong>
              <em>{note as string}</em>
            </div>
          ))}
        </div>
        <div className="dash-grid">
          <section className="panel span-2">
            <div className="panel-head">
              <div>
                <h2>Best matching loads</h2>
                <p>Based on Lagos → Abuja route</p>
              </div>
              <button>View all loads</button>
            </div>
            <div className="load-list">
              {loads.map((load) => (
                <div className="load-row" key={load.id}>
                  <div className="match-ring">
                    <strong>{load.match}%</strong>
                    <small>match</small>
                  </div>
                  <div className="load-main">
                    <div>
                      <strong>{load.route}</strong>
                      <span>{load.id}</span>
                    </div>
                    <p>
                      {load.cargo} · {load.weight} · {load.date}
                    </p>
                  </div>
                  <div className="load-budget">
                    <small>Customer budget</small>
                    <strong>{load.budget}</strong>
                  </div>
                  <button
                    className="btn btn-dark"
                    onClick={() => setOfferLoad(load)}
                  >
                    Make offer
                  </button>
                </div>
              ))}
            </div>
          </section>
          <section className="panel truck-status">
            <div className="panel-head">
              <div>
                <h2>Your vehicle</h2>
                <p>Current fleet status</p>
              </div>
            </div>
            <img src={trucks[0].image} alt="Registered Volvo truck" />
            <h3>Volvo FH16</h3>
            <span>ABC-284-XY · Flatbed</span>
            <div className="vehicle-state">
              <i /> Available for loads
            </div>
            <div className="route-box">
              <MapPin />
              <div>
                <small>Preferred route</small>
                <strong>Lagos → Abuja</strong>
              </div>
            </div>
          </section>
          <section className="panel span-3">
            <div className="panel-head">
              <div>
                <h2>Offer activity</h2>
                <p>Recent offers submitted to customers</p>
              </div>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Load</th>
                    <th>Route</th>
                    <th>Your offer</th>
                    <th>Pickup</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>#LD-2065</td>
                    <td>Lagos → Ilorin</td>
                    <td>₦280,000</td>
                    <td>20 Jun</td>
                    <td>
                      <span className="status">Pending</span>
                    </td>
                  </tr>
                  <tr>
                    <td>#LD-2058</td>
                    <td>Abuja → Lagos</td>
                    <td>₦415,000</td>
                    <td>17 Jun</td>
                    <td>
                      <span className="status">Accepted</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
      {offerLoad && (
        <OfferModal
          load={offerLoad}
          onClose={() => setOfferLoad(null)}
          onSubmit={() => {
            setOfferLoad(null)
            notify("Your demo offer was sent to the customer")
          }}
        />
      )}
      {vehicleOpen && (
        <VehicleModal
          onClose={() => setVehicleOpen(false)}
          onSubmit={() => {
            setVehicleOpen(false)
            notify("Vehicle added to your demo fleet")
          }}
        />
      )}
    </DashboardShell>
  )
}

function AdminDashboard() {
  return (
    <div className="admin-page">
      <aside className="admin-side">
        <Logo compact />
        <nav>
          {[
            [LayoutDashboard, "Overview"],
            [Users, "Users"],
            [Truck, "Trucks"],
            [ClipboardList, "Bookings"],
            [BarChart3, "Reports"],
          ].map(([Icon, label], i) => (
            <button className={i === 0 ? "active" : ""} key={String(label)}>
              <Icon /> <span>{label as string}</span>
            </button>
          ))}
        </nav>
      </aside>
      <div className="admin-content">
        <div className="admin-top">
          <div>
            <span className="kicker">Platform administration</span>
            <h1>SuperFast overview</h1>
          </div>
          <div className="admin-user">
            <div>
              <strong>Amara N.</strong>
              <small>Administrator</small>
            </div>
            <span>AN</span>
          </div>
        </div>
        <div className="admin-stats">
          {[
            [Users, "Total users", "12,842", "+8.2%"],
            [Truck, "Verified trucks", "3,206", "+126"],
            [ClipboardList, "Active bookings", "486", "+14.7%"],
            [CircleDollarSign, "Gross volume", "₦248.6m", "+21.3%"],
          ].map(([Icon, label, value, trend]) => (
            <div key={String(label)}>
              <span>
                <Icon />
              </span>
              <p>{label as string}</p>
              <strong>{value as string}</strong>
              <em>{trend as string} this month</em>
            </div>
          ))}
        </div>
        <div className="admin-grid">
          <section className="panel analytics">
            <div className="panel-head">
              <div>
                <h2>Booking volume</h2>
                <p>Past 7 months</p>
              </div>
              <select>
                <option>Last 7 months</option>
              </select>
            </div>
            <div className="chart">
              {[42, 58, 48, 70, 62, 84, 76].map((h, i) => (
                <div key={i}>
                  <i style={{ height: `${h}%` }} />
                  <span>
                    {["Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun"][i]}
                  </span>
                </div>
              ))}
            </div>
          </section>
          <section className="panel">
            <div className="panel-head">
              <div>
                <h2>Platform health</h2>
                <p>Live demo indicators</p>
              </div>
            </div>
            <div className="health-list">
              {[
                ["Verification queue", "24", "Review"],
                ["Open support tickets", "13", "Normal"],
                ["Disputed bookings", "4", "Low"],
              ].map(([label, value, state]) => (
                <div key={label}>
                  <span>
                    {label}
                    <small>{state}</small>
                  </span>
                  <strong>{value}</strong>
                </div>
              ))}
            </div>
          </section>
          <section className="panel span-2">
            <div className="panel-head">
              <div>
                <h2>Recent activity</h2>
                <p>Latest platform operations</p>
              </div>
              <button>See audit log</button>
            </div>
            <div className="activity-list">
              {[
                ["New driver verified", "Musa Ibrahim · 2 min ago"],
                ["Booking SF-30982 confirmed", "Lagos → Abuja · 18 min ago"],
                ["New truck awaiting review", "Scania R450 · 32 min ago"],
                ["Payment marked complete", "₦415,000 · 1 hr ago"],
              ].map(([title, meta], i) => (
                <div key={title}>
                  <span className={`activity-icon a${i}`}>
                    <CheckCircle2 />
                  </span>
                  <div>
                    <strong>{title}</strong>
                    <small>{meta}</small>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

function AuthModal({
  role,
  onClose,
  onSuccess,
}: {
  role: AuthRole
  onClose: () => void
  onSuccess: () => void
}) {
  const [mode, setMode] = useState<"login" | "register">("login")
  return (
    <Modal
      title={`${
        mode === "login" ? "Welcome back" : "Create your"
      } ${role} account`}
      onClose={onClose}
    >
      <div className="role-switch">
        <button className={role === "customer" ? "active" : ""}>
          <UserRound /> Customer
        </button>
        <button className={role === "driver" ? "active" : ""}>
          <Truck /> Driver
        </button>
      </div>
      <form
        className="modal-form"
        onSubmit={(e) => {
          e.preventDefault()
          onSuccess()
        }}
      >
        {mode === "register" && (
          <label>
            Full name
            <input required placeholder="Your full name" />
          </label>
        )}
        <label>
          Email address
          <input
            required
            type="email"
            placeholder="you@example.com"
            defaultValue="demo@superfast.ng"
          />
        </label>
        <label>
          Password
          <input
            required
            type="password"
            placeholder="Enter your password"
            defaultValue="demopassword"
          />
        </label>
        <div className="form-note">
          <ShieldCheck /> Demo only — no real account or authentication service
          is used.
        </div>
        <button className="btn btn-orange full" type="submit">
          {mode === "login" ? "Open demo dashboard" : "Create demo account"}{" "}
          <ArrowRight />
        </button>
      </form>
      <p className="modal-switch">
        {mode === "login" ? "New to SuperFast?" : "Already have an account?"}{" "}
        <button
          onClick={() => setMode(mode === "login" ? "register" : "login")}
        >
          {mode === "login" ? "Create an account" : "Log in"}
        </button>
      </p>
    </Modal>
  )
}

function BookingModal({
  truck,
  onClose,
  onConfirm,
}: {
  truck: TruckType
  onClose: () => void
  onConfirm: () => void
}) {
  return (
    <Modal title={`Book ${truck.name}`} onClose={onClose}>
      <div className="booking-summary">
        <img src={truck.image} alt={truck.name} />
        <div>
          <span className="status">Verified</span>
          <h3>{truck.route}</h3>
          <p>
            {truck.type} · {truck.capacity} · {truck.driver}
          </p>
          <strong>
            ₦{truck.price.toLocaleString()} <small>estimated trip</small>
          </strong>
        </div>
      </div>
      <form
        className="modal-form"
        onSubmit={(e) => {
          e.preventDefault()
          onConfirm()
        }}
      >
        <div className="form-grid">
          <label>
            Loading date
            <input type="date" required />
          </label>
          <label>
            Cargo weight
            <input placeholder="e.g. 12 tons" required />
          </label>
        </div>
        <label>
          Goods description
          <textarea
            placeholder="Tell the driver what you are moving"
            required
          />
        </label>
        <div className="form-note">
          <ShieldCheck /> This submits a demo request only. No payment will be
          collected.
        </div>
        <button className="btn btn-orange full">
          Request this truck <ArrowRight />
        </button>
      </form>
    </Modal>
  )
}

function RequestModal({
  onClose,
  onSubmit,
}: {
  onClose: () => void
  onSubmit: () => void
}) {
  return (
    <Modal title="Post transportation request" onClose={onClose}>
      <form
        className="modal-form"
        onSubmit={(e) => {
          e.preventDefault()
          onSubmit()
        }}
      >
        <div className="form-grid">
          <label>
            Pickup location
            <input required placeholder="Lagos" />
          </label>
          <label>
            Destination
            <input required placeholder="Abuja" />
          </label>
          <label>
            Loading date
            <input required type="date" />
          </label>
          <label>
            Estimated weight
            <input required placeholder="12 tons" />
          </label>
        </div>
        <label>
          Goods description
          <textarea required placeholder="What needs to be transported?" />
        </label>
        <button className="btn btn-orange full">
          Publish request <ArrowRight />
        </button>
      </form>
    </Modal>
  )
}

function OfferModal({
  load,
  onClose,
  onSubmit,
}: {
  load: typeof loads[0]
  onClose: () => void
  onSubmit: () => void
}) {
  return (
    <Modal title={`Offer for ${load.id}`} onClose={onClose}>
      <div className="offer-summary">
        <MapPin />
        <div>
          <strong>{load.route}</strong>
          <span>
            {load.cargo} · {load.weight}
          </span>
        </div>
        <b>{load.budget}</b>
      </div>
      <form
        className="modal-form"
        onSubmit={(e) => {
          e.preventDefault()
          onSubmit()
        }}
      >
        <label>
          Your offer (₦)
          <input type="number" required placeholder="400000" />
        </label>
        <label>
          Note to customer
          <textarea placeholder="Share availability or trip details" />
        </label>
        <button className="btn btn-orange full">
          Submit competitive offer <ArrowRight />
        </button>
      </form>
    </Modal>
  )
}

function VehicleModal({
  onClose,
  onSubmit,
}: {
  onClose: () => void
  onSubmit: () => void
}) {
  return (
    <Modal title="Register a vehicle" onClose={onClose}>
      <form
        className="modal-form"
        onSubmit={(e) => {
          e.preventDefault()
          onSubmit()
        }}
      >
        <div className="form-grid">
          <label>
            Vehicle make & model
            <input required placeholder="e.g. Volvo FH16" />
          </label>
          <label>
            Plate number
            <input required placeholder="ABC-123-XY" />
          </label>
          <label>
            Truck type
            <select required>
              <option>Flatbed</option>
              <option>Box truck</option>
              <option>Refrigerated</option>
              <option>Tanker</option>
            </select>
          </label>
          <label>
            Capacity
            <input required placeholder="e.g. 22 tons" />
          </label>
          <label>
            Preferred origin
            <input required placeholder="Lagos" />
          </label>
          <label>
            Preferred destination
            <input required placeholder="Abuja" />
          </label>
        </div>
        <div className="form-note">
          <ShieldCheck /> Vehicle details remain demo data and are not sent to a
          backend.
        </div>
        <button className="btn btn-orange full">
          Add demo vehicle <ArrowRight />
        </button>
      </form>
    </Modal>
  )
}

function Footer({ navigate }: { navigate: (page: Page) => void }) {
  return (
    <footer>
      <div className="footer-main">
        <div className="footer-brand">
          <Logo />
          <p>
            Smart truck booking for faster, more efficient logistics across
            Nigeria.
          </p>
          <div className="footer-social">
            <button>in</button>
            <button>f</button>
            <button>𝕏</button>
          </div>
        </div>
        <div>
          <strong>For customers</strong>
          <button onClick={() => navigate("trucks")}>Find a truck</button>
          <button onClick={() => navigate("customer")}>Post a request</button>
          <button>Pricing</button>
          <button>Help center</button>
        </div>
        <div>
          <strong>For drivers</strong>
          <button onClick={() => navigate("driver")}>Find loads</button>
          <button onClick={() => navigate("driver")}>List your truck</button>
          <button>Driver resources</button>
          <button>Safety</button>
        </div>
        <div>
          <strong>Company</strong>
          <button>About us</button>
          <button>Careers</button>
          <button>Contact</button>
          <button onClick={() => navigate("admin")}>Admin demo</button>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2025 SuperFast Technologies. All rights reserved.</span>
        <div>
          <button>Privacy</button>
          <button>Terms</button>
          <button>Cookies</button>
        </div>
      </div>
    </footer>
  )
}
