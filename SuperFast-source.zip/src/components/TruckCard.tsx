import { BadgeCheck, CalendarDays, MapPin, Star, Weight } from "lucide-react"
import type { Truck } from "../data/demo"

type Props = { truck: Truck; onBook: (truck: Truck) => void }

export default function TruckCard({ truck, onBook }: Props) {
  return (
    <article className="truck-card">
      <div className="truck-image">
        <img src={truck.image} alt={`${truck.name} ${truck.type} truck`} />
        <span className="availability">
          {truck.available === "Today"
            ? "Available now"
            : `Available ${truck.available}`}
        </span>
        <button className="heart" aria-label="Save truck">
          ♡
        </button>
      </div>
      <div className="truck-info">
        <div className="truck-title">
          <div>
            <span className="eyebrow">{truck.type}</span>
            <h3>{truck.name}</h3>
          </div>
          <div className="rating">
            <Star size={15} fill="currentColor" /> {truck.rating}
          </div>
        </div>
        <div className="route">
          <MapPin size={16} /> {truck.route}
        </div>
        <div className="truck-meta">
          <span>
            <Weight size={16} /> {truck.capacity}
          </span>
          <span>
            <CalendarDays size={16} /> {truck.trips} trips
          </span>
        </div>
        <div className="driver-row">
          <span className="avatar">
            {truck.driver
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </span>
          <span>
            {truck.driver} <BadgeCheck size={15} />
          </span>
        </div>
        <div className="price-row">
          <div>
            <small>Starting from</small>
            <strong>₦{truck.price.toLocaleString()}</strong>
          </div>
          <button className="btn btn-dark" onClick={() => onBook(truck)}>
            View & book
          </button>
        </div>
      </div>
    </article>
  )
}
