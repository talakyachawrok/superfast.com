import { Truck } from "lucide-react"

export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="logo" aria-label="SuperFast home">
      <span className="logo-mark">
        <Truck size={24} strokeWidth={2.5} />
      </span>
      {!compact && (
        <span>
          Super<span>Fast</span>
        </span>
      )}
    </div>
  )
}
